create function check_and_update_type_ship() returns trigger
    language plpgsql
as
$$
declare
    type_of_rescue_ship ship_type;
BEGIN
    RAISE NOTICE '%', NEW.id_rescue_ship;
    
    SELECT ship.type INTO type_of_rescue_ship FROM ship WHERE ship.id = NEW.id_rescue_ship;
    IF (type_of_rescue_ship = 'distress') then
        RAISE EXCEPTION 'Терпящий бедствие корабль не может прийти на помощь';
    end if;
    UPDATE ship
    SET type = 'distress',
        last_change = now()
    WHERE id = NEW.id_distress_ship;
    UPDATE ship
    SET type = 'rescue',
        last_change = now()
    WHERE id = NEW.id_rescue_ship;
    RETURN NEW;
END;
$$;

alter function check_and_update_type_ship() owner to s409331;

