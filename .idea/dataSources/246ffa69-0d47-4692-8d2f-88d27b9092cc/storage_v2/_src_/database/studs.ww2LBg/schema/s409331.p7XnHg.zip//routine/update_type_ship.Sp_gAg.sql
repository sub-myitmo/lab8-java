create function update_type_ship() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE ship
    SET type = 'distress',
        last_change = now()
    WHERE id = NEW.id_distress_ship;
    RETURN NEW;
END;
$$;

alter function update_type_ship() owner to s409331;

