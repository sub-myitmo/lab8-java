create function check_type_ship() returns trigger
    language plpgsql
as
$$
declare
    type ship_type;
BEGIN
    SELECT ship.type INTO type FROM ship WHERE ship.id = NEW.id_rescue_ship;
    IF (type = 'distress') then
        RAISE EXCEPTION 'Терпящий бедствие корабль не может прийти на помощь';
    end if;
END;
$$;

alter function check_type_ship() owner to s409331;

